﻿
using System.Globalization;
using PLANAZO_POO_CSharp.Modelos;
using PLANAZO_POO_CSharp.Servicios;

namespace PLANAZO_POO_CSharp;

internal class Program
{
    private static readonly GestorReservas Gestor = new();

    private static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        ConfigurarEventos();

        bool continuar = true;

        while (continuar)
        {
            MostrarMenu();
            Console.Write("Seleccione una opción: ");
            string? opcion = Console.ReadLine();

            try
            {
                switch (opcion)
                {
                    case "1":
                        VerEventos();
                        break;
                    case "2":
                        ConsultarEvento();
                        break;
                    case "3":
                        ReservarEntradas();
                        break;
                    case "4":
                        VerReservas();
                        break;
                    case "5":
                        CancelarReserva();
                        break;
                    case "6":
                        VerResumen();
                        break;
                    case "7":
                        ConsultarReservasUsuario();
                        break;
                    case "0":
                        continuar = false;
                        Console.WriteLine("Gracias por utilizar PLANAZO.");
                        break;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"Error de validación: {ex.Message}");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Operación no permitida: {ex.Message}");
            }
            catch (KeyNotFoundException ex)
            {
                Console.WriteLine($"No encontrado: {ex.Message}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"Entrada incorrecta: {ex.Message}");
            }

            if (continuar)
            {
                Console.WriteLine("\nPresione una tecla para continuar...");
                Console.ReadKey();
            }
        }
    }

    private static void ConfigurarEventos()
    {
        Gestor.RegistrarEvento(new Cine(
            1, "Interestelar", DateTime.Now.AddDays(5),
            15000m, 100));

        Gestor.RegistrarEvento(new Cine(
            2, "Coco", DateTime.Now.AddDays(8),
            12000m, 80));

        Gestor.RegistrarEvento(new Concierto(
            3, "Rock en Vivo", DateTime.Now.AddDays(12),
            50000m, 200));

        Gestor.RegistrarEvento(new Concierto(
            4, "Noche de Jazz", DateTime.Now.AddDays(15),
            40000m, 120));

        Gestor.RegistrarEvento(new Taller(
            5, "Fotografía Creativa", DateTime.Now.AddDays(20),
            60000m, 30));

        Gestor.RegistrarEvento(new Taller(
            6, "Pintura para Principiantes",
            DateTime.Now.AddDays(22), 45000m, 25));

        Gestor.RegistrarEvento(new EventoDeportivo(
            7, "Torneo de Fútbol", DateTime.Now.AddDays(25),
            30000m, 150));
    }

    private static void MostrarMenu()
    {
        Console.Clear();
        Console.WriteLine("================================");
        Console.WriteLine("        PLANAZO - EVENTOS");
        Console.WriteLine("================================");
        Console.WriteLine("1. Ver eventos disponibles");
        Console.WriteLine("2. Consultar evento");
        Console.WriteLine("3. Reservar entradas");
        Console.WriteLine("4. Ver reservas realizadas");
        Console.WriteLine("5. Cancelar una reserva");
        Console.WriteLine("6. Ver resumen de reservas");
        Console.WriteLine("7. Consultar reservas por usuario");
        Console.WriteLine("0. Salir");
        Console.WriteLine("================================");
    }

    private static int LeerEntero(string mensaje)
    {
        Console.Write(mensaje);
        string? entrada = Console.ReadLine();

        if (!int.TryParse(entrada, out int valor))
            throw new FormatException("Debe ingresar un número entero.");

        return valor;
    }

    private static string LeerTexto(string mensaje)
    {
        Console.Write(mensaje);
        string? valor = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(valor))
            throw new ArgumentException("El texto no puede estar vacío.");

        return valor.Trim();
    }

    private static void VerEventos()
    {
        Console.WriteLine("\n--- EVENTOS DISPONIBLES ---");

        foreach (Evento evento in Gestor.Eventos)
        {
            if (evento.CuposDisponibles > 0)
                Console.WriteLine(evento);
        }

        if (!Gestor.Eventos.Any(e => e.CuposDisponibles > 0))
            Console.WriteLine("No hay eventos con cupos disponibles.");
    }

    private static void ConsultarEvento()
    {
        int id = LeerEntero("Ingrese el ID del evento: ");
        Evento evento = Gestor.ConsultarEvento(id);

        Console.WriteLine("\n--- DETALLE DEL EVENTO ---");
        Console.WriteLine(evento);
        Console.WriteLine($"Precio base: {evento.PrecioBase:C0}");
        Console.WriteLine($"Precio final: {evento.CalcularPrecioFinal():C0}");
        Console.WriteLine($"Fecha: {evento.Fecha:dd/MM/yyyy HH:mm}");
    }

    private static void ReservarEntradas()
    {
        Console.WriteLine("\n--- NUEVA RESERVA ---");
        VerEventos();

        string nombre = LeerTexto("\nNombre de la persona: ");
        int idEvento = LeerEntero("ID del evento: ");
        int cantidad = LeerEntero("Cantidad de entradas: ");

        Reserva reserva = Gestor.CrearReserva(
            nombre, idEvento, cantidad);

        Console.WriteLine("\n¡Reserva realizada correctamente!");
        Console.WriteLine(reserva);
        Console.WriteLine(
            $"Cupos restantes: {reserva.Evento.CuposDisponibles}");
    }

    private static void VerReservas()
    {
        Console.WriteLine("\n--- RESERVAS REALIZADAS ---");

        if (Gestor.Reservas.Count == 0)
        {
            Console.WriteLine("Todavía no hay reservas.");
            return;
        }

        foreach (Reserva reserva in Gestor.Reservas)
            Console.WriteLine(reserva);
    }

    private static void CancelarReserva()
    {
        int id = LeerEntero("ID de la reserva que desea cancelar: ");

        Gestor.CancelarReserva(id);

        Console.WriteLine("Reserva cancelada correctamente.");
        Console.WriteLine("Los cupos fueron devueltos al evento.");
    }

    private static void VerResumen()
    {
        Console.WriteLine("\n--- RESUMEN DE RESERVAS ---");
        Console.WriteLine(
            $"Reservas activas: {Gestor.CantidadReservasActivas()}");
        Console.WriteLine(
            $"Entradas reservadas: {Gestor.CantidadEntradasActivas()}");
        Console.WriteLine(
            $"Valor total activo: {Gestor.ValorTotalActivo():C0}");
    }

    private static void ConsultarReservasUsuario()
    {
        Console.WriteLine("\n--- USUARIOS REGISTRADOS ---");

        foreach (Usuario usuario in Gestor.Usuarios)
            Console.WriteLine(usuario);

        int idUsuario = LeerEntero("ID del usuario: ");
        List<Reserva> reservas =
            Gestor.ConsultarReservasUsuario(idUsuario);

        Console.WriteLine("\n--- RESERVAS DEL USUARIO ---");

        if (reservas.Count == 0)
        {
            Console.WriteLine("El usuario no tiene reservas.");
            return;
        }

        foreach (Reserva reserva in reservas)
            Console.WriteLine(reserva);
    }
}

