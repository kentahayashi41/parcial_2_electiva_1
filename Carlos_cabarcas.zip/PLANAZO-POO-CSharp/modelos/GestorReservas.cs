
using PLANAZO_POO_CSharp.Modelos;

namespace PLANAZO_POO_CSharp.Servicios;

public class GestorReservas
{
    private readonly List<Evento> _eventos = new();
    private readonly List<Reserva> _reservas = new();
    private readonly List<Usuario> _usuarios = new();

    private int _siguienteReserva = 1;
    private int _siguienteUsuario = 1;

    public IReadOnlyList<Evento> Eventos => _eventos.AsReadOnly();
    public IReadOnlyList<Reserva> Reservas => _reservas.AsReadOnly();
    public IReadOnlyList<Usuario> Usuarios => _usuarios.AsReadOnly();

    public void RegistrarEvento(Evento evento)
    {
        ArgumentNullException.ThrowIfNull(evento);

        if (_eventos.Any(e => e.Id == evento.Id))
            throw new InvalidOperationException(
                "Ya existe un evento con ese ID.");

        _eventos.Add(evento);
    }

    public Evento ConsultarEvento(int id)
    {
        return _eventos.FirstOrDefault(e => e.Id == id)
            ?? throw new KeyNotFoundException(
                $"No existe un evento con el ID {id}.");
    }

    public Usuario ObtenerOCrearUsuario(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre))
            throw new ArgumentException(
                "El nombre del usuario es obligatorio.");

        nombre = nombre.Trim();

        Usuario? existente = _usuarios.FirstOrDefault(
            u => string.Equals(
                u.Nombre, nombre, StringComparison.OrdinalIgnoreCase));

        if (existente is not null)
            return existente;

        var usuario = new Usuario(_siguienteUsuario++, nombre);
        _usuarios.Add(usuario);
        return usuario;
    }

    public Reserva CrearReserva(
        string nombreUsuario, int idEvento, int cantidad)
    {
        if (cantidad <= 0)
            throw new ArgumentException(
                "La cantidad debe ser mayor que cero.");

        Evento evento = ConsultarEvento(idEvento);

        if (cantidad > evento.CuposDisponibles)
            throw new InvalidOperationException(
                $"Solo hay {evento.CuposDisponibles} cupos disponibles.");

        Usuario usuario = ObtenerOCrearUsuario(nombreUsuario);

        // Primero se descuentan los cupos.
        evento.ReservarCupos(cantidad);

        try
        {
            var reserva = new Reserva(
                _siguienteReserva, usuario, evento, cantidad);

            _reservas.Add(reserva);
            _siguienteReserva++;

            return reserva;
        }
        catch
        {
            // Si falla la creación, se restauran los cupos.
            evento.LiberarCupos(cantidad);
            throw;
        }
    }

    public Reserva ConsultarReserva(int id)
    {
        return _reservas.FirstOrDefault(r => r.Id == id)
            ?? throw new KeyNotFoundException(
                $"No existe una reserva con el ID {id}.");
    }

    public void CancelarReserva(int id)
    {
        Reserva reserva = ConsultarReserva(id);
        reserva.Cancelar();
    }

    public List<Reserva> ConsultarReservasUsuario(int idUsuario)
    {
        if (!_usuarios.Any(u => u.Id == idUsuario))
            throw new KeyNotFoundException(
                $"No existe un usuario con el ID {idUsuario}.");

        return _reservas
            .Where(r => r.Usuario.Id == idUsuario)
            .ToList();
    }

    public int CantidadReservasActivas()
        => _reservas.Count(r => r.Activa);

    public int CantidadEntradasActivas()
        => _reservas
            .Where(r => r.Activa)
            .Sum(r => r.CantidadEntradas);

    public decimal ValorTotalActivo()
        => _reservas
            .Where(r => r.Activa)
            .Sum(r => r.ValorTotal);
}
