
namespace PLANAZO_POO_CSharp.Modelos;

public class Usuario
{
    public int Id { get; }
    public string Nombre { get; }

    public Usuario(int id, string nombre)
    {
        if (id <= 0)
            throw new ArgumentException("El ID debe ser positivo.");
        if (string.IsNullOrWhiteSpace(nombre))
            throw new ArgumentException("El nombre es obligatorio.");

        Id = id;
        Nombre = nombre.Trim();
    }

    public override string ToString()
        => $"Usuario #{Id}: {Nombre}";
}
