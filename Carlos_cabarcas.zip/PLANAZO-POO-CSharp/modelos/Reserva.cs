
namespace PLANAZO_POO_CSharp.Modelos;

public class Reserva
{
    public int Id { get; }
    public Usuario Usuario { get; }
    public Evento Evento { get; }
    public int CantidadEntradas { get; }
    public decimal ValorTotal { get; }
    public bool Activa { get; private set; }

    public string Estado => Activa ? "Activa" : "Cancelada";

    public Reserva(int id, Usuario usuario, Evento evento, int cantidad)
    {
        if (id <= 0)
            throw new ArgumentException("El ID debe ser positivo.");
        ArgumentNullException.ThrowIfNull(usuario);
        ArgumentNullException.ThrowIfNull(evento);

        if (cantidad <= 0)
            throw new ArgumentException(
                "La cantidad de entradas debe ser mayor que cero.");

        Id = id;
        Usuario = usuario;
        Evento = evento;
        CantidadEntradas = cantidad;
        ValorTotal = evento.CalcularPrecioFinal() * cantidad;
        Activa = true;
    }

    public void Cancelar()
    {
        if (!Activa)
            throw new InvalidOperationException(
                "Esta reserva ya fue cancelada.");

        Evento.LiberarCupos(CantidadEntradas);
        Activa = false;
    }

    public override string ToString()
    {
        return $"Reserva #{Id} | Usuario: {Usuario.Nombre} " +
               $"| Evento: {Evento.Nombre} " +
               $"| Entradas: {CantidadEntradas} " +
               $"| Total: {ValorTotal:C0} | Estado: {Estado}";
    }
}
